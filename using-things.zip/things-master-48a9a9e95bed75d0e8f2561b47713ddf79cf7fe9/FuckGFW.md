

<h2 id="1">Fuck GFW</h2>
* Install Shadowsocks
    * Windows
    ```
    Download Shadowsocks-4.0.7-win.zip
    ```
    * Ubuntu
    ```
    sudo add-apt-repository ppa:hzwhuang/ss-qt5
    sudo apt-get update
    sudo apt-get install shadowsocks-qt5
    ```
    * iOS
    ```
    Switch to American ID for Appstore
    Download Wingy
    ```
    * Android
    ```
    Download Shadowsocks-nightly-4.4.2.apk
    ```
    
* Config Shadowsocks
```
Address: 45.76.191.198
Port: 8989
Encryption: CHACHA20
Password: imiss
```
到这里我们使用全局模式的话，设备上所有流量都将通过代理。
下面配置浏览器是为了使用“自动模式”，比如国内的网站不走代理，被墙的地址走代理。
原理是使用chrome或者firefox的一个插件（switchyomega）
    
* Install Chrome/Firefox on Windows/Ubuntu

* Install switchyomega
```
Download switchyomega in this project
import settings
```

we are free now!
