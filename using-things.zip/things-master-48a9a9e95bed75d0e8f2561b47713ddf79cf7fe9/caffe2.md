# Setup caffe2 environment 

## Main steps
- CUDA: apt-get install cuda, v9.0 or above
- CUDNN: download cudnn v7.0 from nvidia and run to install
```
for these cuda stuff, test on this local environment, but i believe that we can fix this with anaconda environment variables.
```
- Anaconda: nevermind py2.7 or py3.6, but **we have to setup py2.7 env for detectron**
```
conda create -n ENV-NAME python=2.7
```

- Caffe2: motherfxxker...

    - Remember to read Issues section below before you start to do anything.

    - conda install curl eigen3

    - Then refer to 
https://caffe2.ai/docs/getting-started.html?platform=mac&configuration=compile#anaconda-install-path

    - DO NOT build with conda; just do it by yourself using Custom Build.

    - Enjoy with those fxxking issues.


- cocoapi: not a problem but need a Cython package
- detectron: not a problem but need to copy some caffe2 modules to env(see below)

## Issues
- Multiuser environment, better to change the owner of anaconda directory
- Cython is needed for cocoapi
- Detectron DOES NOT support py3.6
- Detectron need caffe2 modules, to fix this
 
```
cp ../caffe2/build-py27/lib/*.so ../anaconda3/envs/caffe2-py2.7/lib/python2.7/site-packages/lib
```

## To Run Detectron test
- use name 'xwj' to login to 10.0.0.40, passwd is ' '
- source activate caffe2-py2.7
- cd ~/detectron
- python tests/test_spatial_narrow_as_op.py


# Memo
## cmake script
``` 
-DCMAKE_PREFIX_PATH=~/anaconda3/envs/detectron-py2.7
-DCMAKE_INSTALL_PREFIX=~/anaconda3/envs/detectron-py2.7
```
if can not find python
```
-DPYTHON_PACKAGES_PATH=~/anaconda3/envs/detectron-py2.7/lib/python2.7/site-packages
-DPYTHON_LIBRARY=~/anaconda3/envs/detectron-py2.7/lib/libpython2.7.so 
-DPYTHON_INCLUDE_DIR=~/anaconda3/envs/detectron-py2.7/include/python2.7
```

## note
```
2018.02.07 xwj. initial