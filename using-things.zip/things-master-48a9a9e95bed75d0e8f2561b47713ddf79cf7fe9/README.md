# Things
#### update info
- 2018.03.07 add debug tricks file


## Misc.
* [Fuck GFW](FuckGFW.md)

## Conf.
* [Caffe2 env](caffe2.md)

## Dev. tools
* [IDE](ide.md)
* [GIT](git.md)
* [Beyond Compare 4 Crack](BC4.crack.linux.md)
* [Debug Tricks](debug-tricks.md)