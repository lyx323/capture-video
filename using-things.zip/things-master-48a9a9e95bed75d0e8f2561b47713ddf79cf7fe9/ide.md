# IDE 

### Visual Code (open source)

### CLion for c++
activation server: http://license.topnguyen.net

### PyCharm for python
activation: http://idea.lanyus.com/