#GIT

```
git clone

git add

git commit

git push

git check out

git branch
```
#Coding Guide
中文版
http://zh-google-styleguide.readthedocs.io/en/latest/google-cpp-styleguide/
