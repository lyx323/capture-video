# 缘分更新

## Linux下有一些IDE可以选择
- Visual Code，需要一些环境配置，不高兴的同学继续往下看
- CLion，商业软件，基于cmake的构建系统，很赞，crack可以参考ide.md
- Pycharm，商业软件，也是非常awesome，crack可以参考ide.md
- Qt，颜值控强烈抵制
- KDE，......
- Vim，HardCore模式
- 移动端？ Android Studio，命令行adb，logcat....

## So？
- IDE基本能解决我们绝大部分的问题，非常强力的可视化debug环境
- 比如Visual Studio，地球表面最强IDE
- 霸特，我仍然希望了解一下what the hell is going on...
- 请先远离IDE

## 怎样精准定位crash
- 一般来说通过猜测、屏蔽部分代码、添加log可以定位大部分的crash
- 以上会比较耗时，正常思维，懒人模式
- HardCore模式是通过解析crash dump来定位
    - 什么是dump file？
        - **可执行文件在crash时，输出、保存下来的灾难现场，包括堆栈、寄存器等信息**
    - dump file在哪？怎么查看？
        - ubuntu 
            - 在终端输入 ```ulimit -c unlimited``` 允许存储dump
            - 程序运行中发生crash将在当前目录生成名为```core```的文件
            - ```gdb Your_Program core```
            - 哒哒～ crash信息就会出现了
        - android
            - 可以在系统目录中寻找到txt文件
            - 也可以通过 ```adb logcat``` 其实是dump文件输出到log了
    - dump file长什么样？
        - 就是你最不想看到的样子
        
        ```
        01-18 09:01:49.096  6652  6653 E libc++abi: terminating with uncaught exception of type std::bad_alloc: std::bad_alloc
        01-18 09:01:49.096  6652  6653 F libc    : Fatal signal 6 (SIGABRT), code -6 in tid 6653 (VINS_Android)
        01-18 09:01:49.199   259   259 F DEBUG   : *** *** *** *** *** *** *** *** *** *** *** *** *** *** *** ***
        01-18 09:01:49.199   259   259 F DEBUG   : Build fingerprint: 'Android/rk3399_box/rk3399_box:6.0.1/MXC89L/dfyuan10270957:userdebug/test-keys'
        01-18 09:01:49.199   259   259 F DEBUG   : Revision: '0'
        01-18 09:01:49.199   525   733 W NativeCrashListener: Couldn't find ProcessRecord for pid 6652
        01-18 09:01:49.199   259   259 F DEBUG   : ABI: 'arm64'
        01-18 09:01:49.200   259   259 F DEBUG   : pid: 6652, tid: 6653, name: VINS_Android  >>> ./VINS_Android <<<
        01-18 09:01:49.200   259   259 E DEBUG   : AM write failed: Broken pipe
        01-18 09:01:49.200   259   259 F DEBUG   : signal 6 (SIGABRT), code -6 (SI_TKILL), fault addr --------
        01-18 09:01:49.210   259   259 F DEBUG   : Abort message: 'terminating with uncaught exception of type std::bad_alloc: std::bad_alloc'
        01-18 09:01:49.210   259   259 F DEBUG   :     x0   0000000000000000  x1   00000000000019fd  x2   0000000000000006  x3   0000000000000000
        01-18 09:01:49.210   259   259 F DEBUG   :     x4   0000000000000000  x5   0000000000000001  x6   0000000000000000  x7   0000000000000000
        01-18 09:01:49.210   259   259 F DEBUG   :     x8   0000000000000083  x9   0000000000000008  x10  0000007fb3a9b93c  x11  000000000000000a
        01-18 09:01:49.210   259   259 F DEBUG   :     x12  000000000000004b  x13  0000000000000000  x14  0000000000000000  x15  0005c4d11744d4d7
        01-18 09:01:49.210   259   259 F DEBUG   :     x16  0000007fb3c9d6a0  x17  0000007fb3c5f8dc  x18  00000000ffffffe0  x19  0000007fb3a9d510
        01-18 09:01:49.211   259   259 F DEBUG   :     x20  0000007fb3a9d450  x21  0000000000000002  x22  0000000000000006  x23  00000000ffffffc8
        01-18 09:01:49.211   259   259 F DEBUG   :     x24  0000007fb3a9c6a0  x25  0000007fb3a9c570  x26  0000007fb3a9c5b0  x27  0000000000000009
        01-18 09:01:49.211   259   259 F DEBUG   :     x28  000000557f9fc420  x29  0000007fb3a9c430  x30  0000007fb3c5d078
        01-18 09:01:49.211   259   259 F DEBUG   :     sp   0000007fb3a9c430  pc   0000007fb3c5f8e4  pstate 0000000020000000
        01-18 09:01:49.255   259   259 F DEBUG   : 
        01-18 09:01:49.255   259   259 F DEBUG   : backtrace:
        01-18 09:01:49.256   259   259 F DEBUG   :     #00 pc 000000000006a8e4  /system/lib64/libc.so (tgkill+8)
        01-18 09:01:49.256   259   259 F DEBUG   :     #01 pc 0000000000068074  /system/lib64/libc.so (pthread_kill+68)
        01-18 09:01:49.256   259   259 F DEBUG   :     #02 pc 0000000000020e08  /system/lib64/libc.so (raise+28)
        01-18 09:01:49.256   259   259 F DEBUG   :     #03 pc 000000000001b5a8  /system/lib64/libc.so (abort+60)
        01-18 09:01:49.256   259   259 F DEBUG   :     #04 pc 0000000000579b14  /data/VINS_Android (abort_message+248)
        01-18 09:01:49.256   259   259 F DEBUG   :     #05 pc 0000000000579c24  /data/VINS_Android (_ZL28demangling_terminate_handlerv+268)
        01-18 09:01:49.256   259   259 F DEBUG   :     #06 pc 0000000000576e3c  /data/VINS_Android (_ZSt11__terminatePFvvE+12)
        01-18 09:01:49.256   259   259 F DEBUG   :     #07 pc 00000000005765a8  /data/VINS_Android (__cxa_throw+128)
        01-18 09:01:49.256   259   259 F DEBUG   :     #08 pc 00000000000a4ac4  /data/VINS_Android (_ZN14FeatureManager11removeFrontEi+1504)
        01-18 09:01:49.256   259   259 F DEBUG   :     #09 pc 0000000000097880  /data/VINS_Android (_ZN9Estimator14slideWindowNewEv+200)
        01-18 09:01:49.257   259   259 F DEBUG   :     #10 pc 00000000000910f0  /data/VINS_Android (_ZN9Estimator11slideWindowEv+1828)
        01-18 09:01:49.257   259   259 F DEBUG   :     #11 pc 000000000008db54  /data/VINS_Android (_ZN9Estimator12processImageERKNSt6__ndk13mapIiNS0_6vectorINS0_4pairIiN5Eigen6MatrixIdLi3ELi1ELi0ELi3ELi1EEEEENS0_9allocatorIS7_EEEENS0_4lessIiEENS8_INS3_IKiSA_EEEEEERKN8std_msgs7Header_INS8_IvEEEE+2968)
        01-18 09:01:49.257   259   259 F DEBUG   :     #12 pc 00000000000fc35c  /data/VINS_Android (_Z7processv+984)
        01-18 09:01:49.257   259   259 F DEBUG   :     #13 pc 00000000001076e4  /data/VINS_Android (_ZNSt6__ndk114__thread_proxyINS_5tupleIJNS_10unique_ptrINS_15__thread_structENS_14default_deleteIS3_EEEEPFvvEEEEEEPvSA_+44)
        01-18 09:01:49.257   259   259 F DEBUG   :     #14 pc 00000000000674c4  /system/lib64/libc.so (_ZL15__pthread_startPv+52)
        01-18 09:01:49.257   259   259 F DEBUG   :     #15 pc 000000000001c154  /system/lib64/libc.so (__start_thread+16)
        01-18 09:01:49.397   259   259 F DEBUG   : 
        01-18 09:01:49.397   259   259 F DEBUG   : Tombstone written to: /data/tombstones/tombstone_05
        ```
        - **还有不少信息需要补充，以后再更新，现在先关注怎么定位crash**

## 我们还是举个栗子吧
- 比如我写了段代码如下
    ```c++
    #include <iostream>

    int crash_maker()
    {
        int *i_am_a_null_pointer = 0;

        *i_am_a_null_pointer = 9527;

        return -1;
    }

    int add_stack_layer()
    {
        crash_maker();

        return 0;
    }

    int main(int argc, char** argv)
    {
        add_stack_layer();

        std::cout << "can u see me?" << std::endl;

        return 0;
    }

    ```
- 编译之

```bash
$ g++ main.cpp -o main
```
- 运行后crash了，完全在我们预料之中，屏幕上打印如下

```
$ ./main
Segmentation fault (core dumped)

```
- 除此之外，如果之前我们允许了core dump的话，在当前文件夹下应该有个core文件，gdb在手，天下我有

```bash
$ gdb main core
```
- OK，这个时候屏幕上应该打出如下废话+很重要的信息，**注意最后5行**

```
GNU gdb (Ubuntu 7.11.1-0ubuntu1~16.5) 7.11.1
Copyright (C) 2016 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.  Type "show copying"
and "show warranty" for details.
This GDB was configured as "x86_64-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
<http://www.gnu.org/software/gdb/documentation/>.
For help, type "help".
Type "apropos word" to search for commands related to "word"...
Reading symbols from main...(no debugging symbols found)...done.
[New LWP 29322]
Core was generated by `./main'.
Program terminated with signal SIGSEGV, Segmentation fault.
#0  0x0000000000400856 in crash_maker() ()
(gdb) 
```
- 实践告诉我们上面程序的crash在一个叫```crash_maker```的函数里，和一个64位的地址
    - 定位到函数了，不错
    - 如果函数在很多地方被调用怎么办
    - 继续,注意最后我们进入了gdb调试模式，输入bt（意思是backtrace）

```
$ (gdb) bt

``` 
- backtrace将打印出如下所示的本次车祸现场，类似于大家熟悉的函数调用堆栈

```
#0  0x0000000000400856 in crash_maker() ()
#1  0x000000000040086c in add_stack_layer() ()
#2  0x0000000000400887 in main ()
```
- 实践再一次告诉我们crash所在的函数以及它之前的所有调用信息
    - OK，如果这个函数有10000行怎么办，我只是举个栗子
    - 没办法了，因为编译出来的文件没有包含更多的调试信息，例如行号，文件名等等
- 如何添加调试信息到可执行文件中
    - 重新编译，**添加-g选项**

```bash
$ g++ main.cpp -o main -g
```
- 这个时候我们如果重复之前的操作，gdb、bt...会看到下面的废话+重要信息，**注意最后七行**

```
GNU gdb (Ubuntu 7.11.1-0ubuntu1~16.5) 7.11.1
Copyright (C) 2016 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.  Type "show copying"
and "show warranty" for details.
This GDB was configured as "x86_64-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
<http://www.gnu.org/software/gdb/documentation/>.
For help, type "help".
Type "apropos word" to search for commands related to "word"...
Reading symbols from main...done.

warning: exec file is newer than core file.
[New LWP 16513]
Core was generated by `./main'.
Program terminated with signal SIGSEGV, Segmentation fault.
#0  0x0000000000400856 in crash_maker () at main.cpp:7
7	    *i_am_a_null_pointer = 9527;
(gdb) bt
#0  0x0000000000400856 in crash_maker () at main.cpp:7
#1  0x000000000040086c in add_stack_layer () at main.cpp:14
#2  0x0000000000400887 in main (argc=1, argv=0x7fff42dde858) at main.cpp:21
(gdb)
```
- 这样我们不仅拿到了函数堆栈，还有crash所在文件以及行数

## 其他
- 比如Android，我们用logcat直接看到了各种堆栈信息，然后怎么办？
- 也就是说我可能已经定位到函数这一级别了，比如在举例dump file时贴出来的那一堆
- 有请神器```addr2line```登场，我们还需要用到之前提到的64位地址
- 下面我截取backtrace的一条信息来尝试

```
01-18 09:01:49.256   259   259 F DEBUG   :     #05 pc 0000000000579c24  /data/VINS_Android (_ZL28demangling_terminate_handlerv+268)
```
- 使用```addr2line```来找到文件及行数

```
$ addr2line 0000000000579c24 -Cfe  ~/VINS_Android
```
- 输出如下

```
demangling_terminate_handler()
/usr/local/google/buildbot/src/android/ndk-release-r16/external/libcxx/../../external/libcxxabi/src/cxa_default_handlers.cpp:63
```
- 我们定位到这个文件打开源代码，定位到63行看一下

```c++
24 __attribute__((noreturn))
25 static void default_terminate_handler()
//
// 此处省略若干行
//
59 if (catch_type->can_catch(thrown_type, thrown_object))
60 {
61    // Include the what() message from the exception
62    const std::exception* e = static_cast<const std::exception*>(thrown_object);
63    abort_message("terminating with %s exception of type %s: %s",
64                    cause, name, e->what());
65 }
```

- 此外，注意到下方小括号内，加号后面的数字268，这是一个十进制数，转换为十六进制是0x10C，用0x579c24 减去 0x10C，得到0x579b18，如果对这个新地址用addr2line，可以得到该函数的首地址，必须是. 也就是说这个268表示的是返回地址相对于它所在函数首地址的偏移量。

```
01-18 09:01:49.256   259   259 F DEBUG   :     #05 pc 0000000000579c24  /data/VINS_Android (_ZL28demangling_terminate_handlerv+268)
```

----

# 缘分更新 by xwj@2018.03.06
